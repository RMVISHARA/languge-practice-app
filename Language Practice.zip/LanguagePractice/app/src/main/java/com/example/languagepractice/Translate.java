package com.example.languagepractice;

public class Translate {
}
