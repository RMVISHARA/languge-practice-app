package com.example.languagepractice;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Phrase.db";
    public static final String TABLE_NAME = "Phrase_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "PHRASE";



    public DatabaseHelper(Context context   ) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, PHRASE TEXT UNIQUE )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME );
        onCreate(db);
    }
    // method to insert data

    public boolean insertData (String phrase){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,phrase);
        long result = db.insertWithOnConflict(TABLE_NAME,null, contentValues,SQLiteDatabase.CONFLICT_REPLACE);
        if (result == -1)
            return false;
        else
            return true;
    }
    // method to view data

    public Cursor viewData(){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * from " + TABLE_NAME + " Order by " + COL_2 +" ASC" ;
        Cursor cursor = db.rawQuery(query, null);

        return cursor;
    }
    //edit data get ID
    public Cursor getNameID(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "Select " + COL_1 + " FROM " + TABLE_NAME + " WHERE " + COL_2 + " = '" + name + "'";
        Cursor data = db.rawQuery(query, null);
        return data;

    }
    public void updateName(String newName, int id, String oldName){
        SQLiteDatabase db = this.getWritableDatabase();
        String query  = " UPDATE " + TABLE_NAME + " SET " + COL_2 + " = '" + newName + "' WHERE " + COL_1 +
                "= '" + id + "'" + "AND " + COL_2 + " = '" + oldName + "'";
        db.execSQL(query);
    }

}
