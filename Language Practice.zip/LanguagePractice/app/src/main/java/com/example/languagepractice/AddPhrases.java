package com.example.languagepractice;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddPhrases extends AppCompatActivity {
    DatabaseHelper dbCreate;
    EditText editPhrase;
    Button btnAddPhrase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_phrase);
        dbCreate = new DatabaseHelper(this);
        editPhrase = (EditText) findViewById(R.id.enterPhrase_text);
        btnAddPhrase = (Button) findViewById(R.id.submit_btn);
        AddData();
    }
    public void AddData(){
        btnAddPhrase.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = dbCreate.insertData(editPhrase.getText().toString().toLowerCase());
                        if(isInserted = true)
                            Toast.makeText(AddPhrases.this,"Data Inserted",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(AddPhrases.this,"Data Not Inserted",Toast.LENGTH_LONG).show();

                    }
                }
        );
    }
}
