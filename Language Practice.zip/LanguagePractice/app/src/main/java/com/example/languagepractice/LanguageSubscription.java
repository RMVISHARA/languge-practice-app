package com.example.languagepractice;

public class LanguageSubscription {
}
