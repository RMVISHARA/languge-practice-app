package com.example.languagepractice;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EditPhrases extends AppCompatActivity {
    DatabaseHelper dbCreate;
    ArrayList<String> listItem;
    ArrayAdapter adapter;
    ListView userList;
    private EditText addName;
    private Button updateData;
    private Integer selectedID;
    private String selectedName;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        dbCreate = new DatabaseHelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_phrases);
        listItem = new ArrayList<>();
        userList = findViewById(R.id.users_list);
        addName = findViewById(R.id.add_name);
        updateData = findViewById(R.id.update_data);
        viewData();

        userList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                userList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                userList.setSelection(0);
                userList.setSelected(true);
                String name = userList.getItemAtPosition(position).toString();
                Toast.makeText(EditPhrases.this, ""+ name, Toast.LENGTH_SHORT).show();
                Cursor data = dbCreate.getNameID(name); // get the id associated with that name
                int nameID = -1;
                while (data.moveToNext()){
                    nameID = data.getInt(0);
                }
                if(nameID> -1){
                    Toast.makeText(EditPhrases.this,"On NameClick you Clicked On " + nameID,Toast.LENGTH_LONG).show();
                    addName.setText(name);
                    selectedID = nameID;
                    selectedName = name;
                }else{
                    Toast.makeText(EditPhrases.this,"No Item Associated With That Name ",Toast.LENGTH_LONG).show();

                }
            }
        });


        updateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String addName = EditPhrases.this.addName.getText().toString();
                if(!addName.equals("")){
                    dbCreate.updateName(addName, selectedID,selectedName );
                    adapter.notifyDataSetChanged();
                    Toast.makeText(EditPhrases.this,"Updated",Toast.LENGTH_LONG).show();


                }
                else{
                    Toast.makeText(EditPhrases.this,"You Must Enter A Name",Toast.LENGTH_LONG).show();
                }
            }
        });


    }
    private void viewData(){
        Cursor  cursor = dbCreate.viewData();

        if(cursor.getCount() == 0){
            Toast.makeText(this,"No Data To Show", Toast.LENGTH_SHORT).show();
        }else {
            while (cursor.moveToNext()){
                listItem.add(cursor.getString(1)); //1 is name 0 is id
            }
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, listItem);
            userList.setAdapter(adapter);
        }


    }



}
