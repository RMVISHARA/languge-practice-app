package com.example.languagepractice;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class DisplayPhrases extends AppCompatActivity {
    DatabaseHelper dbCreate;
    ArrayList<String> listItem;
    ArrayAdapter adapter;
    ListView userList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        dbCreate = new DatabaseHelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_phrases);

        listItem = new ArrayList<>();
        userList = findViewById(R.id.users_list);

        viewData();

    }
    private void viewData(){
        Cursor  cursor = dbCreate.viewData();

        if(cursor.getCount() == 0){
            Toast.makeText(this,"No Data To Show", Toast.LENGTH_SHORT).show();
        }else {
            while (cursor.moveToNext()){
                listItem.add(cursor.getString(1)); //1 is name 0 is id
            }
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItem);
            userList.setAdapter(adapter);
        }


    }



}

